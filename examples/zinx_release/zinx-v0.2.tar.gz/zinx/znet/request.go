package znet

import "zinx/ziface"

type Request struct {
	conn ziface.IConnection //已经和客户端建立好的 链接
	date []byte //客户端请求的数据
}
